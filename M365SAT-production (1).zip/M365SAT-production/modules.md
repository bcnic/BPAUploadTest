M365SAT.psm1:
- Invoke-M365SAT
- Test-M365SAT
- Connect-M365SAT
- Disconnect-M365SAT
- Check-M365SATUpdates

Core Modules:
- Get-M365SATReport
- Get-M365SATModuleUpdates
- Get-M365SATGetInspectors